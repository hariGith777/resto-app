import { handler } from './src/public/qr/startSession.js';
import { query, default as db } from './src/libs/db.js';

async function testMultiCustomerSession() {
  try {
    console.log('🔍 TESTING MULTI-CUSTOMER SESSION REUSE\n');
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Get a test table
    const tablesRes = await query('SELECT id FROM tables LIMIT 1');
    const tableId = tablesRes.rows[0]?.id;
    
    console.log('Test Setup:');
    console.log(`Table ID: ${tableId}\n`);
    
    // Step 1: First customer scans QR
    console.log('Step 1: Customer 1 scans QR code\n');
    console.log('─'.repeat(55));
    
    const response1 = await handler({
      body: JSON.stringify({ tableId })
    });
    
    const result1 = JSON.parse(response1.body);
    console.log(`Status: ${response1.statusCode}`);
    console.log(`Session ID: ${result1.sessionId}`);
    console.log(`Is New: ${result1.isNew}`);
    console.log(`Response: ${result1.isNew ? '✅ Created new session' : '❌ Should create new'}\n`);
    
    const sessionId1 = result1.sessionId;
    
    // Step 2: Second customer scans QR (same table)
    console.log('Step 2: Customer 2 scans QR code (same table)\n');
    console.log('─'.repeat(55));
    
    const response2 = await handler({
      body: JSON.stringify({ tableId })
    });
    
    const result2 = JSON.parse(response2.body);
    console.log(`Status: ${response2.statusCode}`);
    console.log(`Session ID: ${result2.sessionId}`);
    console.log(`Is New: ${result2.isNew}`);
    console.log(`Response: ${!result2.isNew ? '✅ Reused existing session' : '❌ Should reuse'}\n`);
    
    const sessionId2 = result2.sessionId;
    
    // Step 3: Verify it's the same session
    console.log('═══════════════════════════════════════════════════════');
    console.log('VERIFICATION\n');
    console.log('─'.repeat(55));
    
    const isSameSession = sessionId1 === sessionId2;
    console.log(`Session 1 ID: ${sessionId1}`);
    console.log(`Session 2 ID: ${sessionId2}`);
    console.log(`Same Session: ${isSameSession ? '✅ YES' : '❌ NO'}\n`);
    
    // Step 4: Verify both sessions exist in database
    const sessionsCheck = await query(
      'SELECT id, table_id, status, started_at, ended_at FROM table_sessions WHERE table_id = $1 ORDER BY started_at DESC LIMIT 5',
      [tableId]
    );
    
    console.log(`Active Sessions for this table: ${sessionsCheck.rows.length}`);
    sessionsCheck.rows.forEach((session, i) => {
      console.log(`  ${i + 1}. ID: ${session.id.substring(0, 8)}...`);
      console.log(`     Status: ${session.status || 'OPEN'}`);
      console.log(`     Started: ${session.started_at}`);
      console.log(`     Ended: ${session.ended_at || 'Still Active'}`);
    });
    console.log('');
    
    // Step 5: Show the benefit
    console.log('═══════════════════════════════════════════════════════');
    console.log('BENEFIT: Multi-Customer Session\n');
    console.log('─'.repeat(55));
    
    console.log('Before fix:');
    console.log('  Customer 1 → Session A');
    console.log('  Customer 2 → Session B ❌ (Separate bill, separate KOT)');
    console.log('');
    
    console.log('After fix:');
    console.log('  Customer 1 → Session A');
    console.log('  Customer 2 → Session A ✅ (Same bill, same KOT list)');
    console.log('');
    
    console.log('═══════════════════════════════════════════════════════');
    console.log('RESULT\n');
    
    if (isSameSession && result1.isNew && !result2.isNew) {
      console.log('✅ SUCCESS: Multi-customer session reuse working correctly!\n');
      console.log('Now two customers at the same table:');
      console.log('  • See the same menu');
      console.log('  • Place orders in same session');
      console.log('  • Kitchen sees all orders on one KOT');
      console.log('  • Can split bill easily\n');
    } else {
      console.log('❌ FAILED: Session reuse not working as expected\n');
    }
    
    console.log('═══════════════════════════════════════════════════════\n');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error(error);
  } finally {
    await db.pool.end();
  }
}

testMultiCustomerSession();
