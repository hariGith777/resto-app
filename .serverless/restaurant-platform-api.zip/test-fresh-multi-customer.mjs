import { handler } from './src/public/qr/startSession.js';
import { query, default as db } from './src/libs/db.js';

async function testFreshSession() {
  try {
    console.log('🔍 TESTING MULTI-CUSTOMER SESSION REUSE (Fresh Scenario)\n');
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Get area for test table
    const areaRes = await query('SELECT id FROM areas LIMIT 1');
    const areaId = areaRes.rows[0].id;
    
    // Create a temporary test table
    const tableRes = await query(
      `INSERT INTO tables(area_id, table_number, capacity, is_active) 
       VALUES($1, $2, 4, true) RETURNING id`,
      [areaId, 'T' + Math.random().toString(36).substring(2, 8)]
    );
    const tableId = tableRes.rows[0].id;
    console.log('Created fresh test table:', tableId.substring(0, 8) + '...\n');
    
    // Test 1: First customer
    console.log('Step 1: Customer 1 scans QR\n');
    console.log('─'.repeat(55));
    const r1 = await handler({ body: JSON.stringify({ tableId }) });
    const res1 = JSON.parse(r1.body);
    console.log('Response:', JSON.stringify(res1, null, 2));
    console.log('Status Code:', r1.statusCode);
    console.log('Is New:', res1.isNew ? '✅ YES' : '❌ NO');
    const sessionId1 = res1.sessionId;
    console.log('Session 1 ID:', sessionId1.substring(0, 8) + '...\n');
    
    // Test 2: Second customer (same table)
    console.log('Step 2: Customer 2 scans QR (same table)\n');
    console.log('─'.repeat(55));
    const r2 = await handler({ body: JSON.stringify({ tableId }) });
    const res2 = JSON.parse(r2.body);
    console.log('Response:', JSON.stringify(res2, null, 2));
    console.log('Status Code:', r2.statusCode);
    console.log('Is New:', res2.isNew ? '❌ NO' : '✅ YES (Reused)');
    const sessionId2 = res2.sessionId;
    console.log('Session 2 ID:', sessionId2.substring(0, 8) + '...\n');
    
    // Verification
    console.log('═══════════════════════════════════════════════════════');
    console.log('VERIFICATION\n');
    console.log('Same Session:', sessionId1 === sessionId2 ? '✅ YES' : '❌ NO');
    console.log('First is New:', res1.isNew ? '✅ YES' : '❌ NO');
    console.log('Second Reused:', !res2.isNew ? '✅ YES' : '❌ NO');
    console.log('');
    
    if (sessionId1 === sessionId2 && res1.isNew && !res2.isNew) {
      console.log('✅ SUCCESS: Multi-customer session reuse working!\n');
      console.log('Now both customers:');
      console.log('  • Can see the same menu');
      console.log('  • Can place orders in same session');
      console.log('  • Kitchen sees all orders on one KOT');
      console.log('  • Bill can be consolidated\n');
    } else {
      console.log('❌ FAILED: Not working as expected\n');
    }
    
    console.log('═══════════════════════════════════════════════════════\n');
    
    await db.pool.end();
  } catch (err) {
    console.error('Error:', err.message);
    console.error(err);
    process.exit(1);
  }
}

testFreshSession();
