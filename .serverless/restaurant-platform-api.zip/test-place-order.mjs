import { query, default as db } from './src/libs/db.js';
import { handler } from './src/public/order/placeOrder.js';

async function testPlaceOrder() {
  try {
    console.log('🔍 Step 1: Fetching test data from database...\n');
    
    // Get a session
    const sessionsRes = await query('SELECT id, table_id, status FROM table_sessions LIMIT 1');
    if (sessionsRes.rows.length === 0) {
      console.error('❌ No sessions found. Please create a session first.');
      process.exit(1);
    }
    const sessionId = sessionsRes.rows[0].id;
    console.log(`✅ Found session: ${sessionId}`);
    console.log(`   Table ID: ${sessionsRes.rows[0].table_id}`);
    console.log(`   Status: ${sessionsRes.rows[0].status}\n`);
    
    // Get menu items
    const menuItemsRes = await query('SELECT id, name, base_price FROM menu_items LIMIT 3');
    if (menuItemsRes.rows.length === 0) {
      console.error('❌ No menu items found. Please seed the database first.');
      process.exit(1);
    }
    
    console.log('✅ Found menu items:');
    menuItemsRes.rows.forEach((item, i) => {
      console.log(`   ${i + 1}. ${item.name} - ₹${item.base_price} (ID: ${item.id})`);
    });
    console.log('');
    
    // Prepare test order
    const testOrderItems = menuItemsRes.rows.slice(0, 2).map(item => ({
      menuItemId: item.id,
      qty: Math.floor(Math.random() * 3) + 1 // Random qty 1-3
    }));
    
    console.log('🧪 Step 2: Testing placeOrder handler...\n');
    console.log('Request:');
    console.log(`  sessionId: ${sessionId}`);
    console.log(`  items:`, testOrderItems);
    console.log('');
    
    // Call the handler
    const response = await handler({
      queryStringParameters: { sessionId },
      body: JSON.stringify({ items: testOrderItems })
    });
    
    console.log('Response:');
    console.log(`  Status Code: ${response.statusCode}`);
    console.log(`  Body:`, JSON.parse(response.body));
    console.log('');
    
    if (response.statusCode === 201) {
      const result = JSON.parse(response.body);
      console.log('✅ SUCCESS! Order placed successfully\n');
      
      // Verify order in database
      console.log('🔍 Step 3: Verifying order in database...\n');
      
      const orderRes = await query(
        `SELECT o.*, oi.menu_item_id, oi.qty, oi.price, mi.name as item_name
         FROM orders o
         LEFT JOIN order_items oi ON o.id = oi.order_id
         LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id
         WHERE o.id = $1`,
        [result.orderId]
      );
      
      console.log('Order Details:');
      console.log(`  Order ID: ${result.orderId}`);
      console.log(`  Status: ${orderRes.rows[0].status}`);
      console.log(`  Total: ₹${result.totalAmount}`);
      console.log(`  Items:`);
      orderRes.rows.forEach((row, i) => {
        console.log(`    ${i + 1}. ${row.item_name} x${row.qty} @ ₹${row.price}`);
      });
      console.log('');
      
      // Check KOT
      const kotRes = await query(
        'SELECT id, status, created_at FROM kots WHERE order_id = $1',
        [result.orderId]
      );
      
      if (kotRes.rows.length > 0) {
        console.log('✅ KOT created:');
        console.log(`  KOT ID: ${kotRes.rows[0].id}`);
        console.log(`  Status: ${kotRes.rows[0].status}`);
        console.log(`  Created: ${kotRes.rows[0].created_at}`);
      }
      
      console.log('\n✨ Test completed successfully!\n');
    } else {
      console.log('❌ FAILED! Order placement failed\n');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error(error);
  } finally {
    await db.pool.end();
  }
}

testPlaceOrder();
