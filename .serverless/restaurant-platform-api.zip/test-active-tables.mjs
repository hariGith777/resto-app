import { handler } from './src/staff/activeTables.js';
import { handler as loginHandler } from './src/staff/login.js';
import { default as db } from './src/libs/db.js';

async function testActiveTables() {
  try {
    console.log('🔍 TESTING ACTIVE TABLES API (WITH BRANCH FILTERING)\n');
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Step 1: Login as captain to get token
    console.log('Step 1: Logging in as captain...\n');
    const loginResponse = await loginHandler({
      body: JSON.stringify({ username: 'captain_raj' })
    });
    
    if (loginResponse.statusCode !== 200) {
      console.log('❌ Login failed:', JSON.parse(loginResponse.body));
      return;
    }
    
    const loginData = JSON.parse(loginResponse.body);
    const token = loginData.token;
    const branchId = loginData.branchId;
    
    console.log(`✅ Logged in successfully`);
    console.log(`   Role: ${loginData.role}`);
    console.log(`   Branch ID: ${branchId}\n`);
    
    // Step 2: Call activeTables with token
    console.log('Step 2: Fetching active tables for this branch...\n');
    const response = await handler({
      headers: { authorization: `Bearer ${token}` }
    });
    
    const activeTables = JSON.parse(response.body);
    
    console.log(`Status Code: ${response.statusCode}\n`);
    
    if (response.statusCode === 200) {
      console.log(`✅ Found ${activeTables.length} active session(s) in captain's branch:\n`);
      
      if (activeTables.length === 0) {
        console.log('   No active sessions found in this branch.');
        console.log('   Tip: Scan a QR code or call /public/qr/session/start to create one.\n');
      } else {
        // Get table details for each session
        for (let i = 0; i < activeTables.length; i++) {
          const session = activeTables[i];
          
          // Get table info
          const tableRes = await db.query(
            `SELECT t.table_number, a.name as area_name, t.capacity, a.branch_id
             FROM tables t
             JOIN areas a ON t.area_id = a.id
             WHERE t.id = $1`,
            [session.table_id]
          );
          
          const table = tableRes.rows[0];
          
          // Verify it's from the correct branch
          const isCorrectBranch = table.branch_id === branchId;
          
          // Get order count for this session
          const orderCountRes = await db.query(
            'SELECT COUNT(*) as count FROM orders WHERE session_id = $1',
            [session.id]
          );
          const orderCount = parseInt(orderCountRes.rows[0].count);
          
          console.log(`${i + 1}. Session ID: ${session.id}`);
          console.log(`   Table: ${table.table_number} (${table.area_name})`);
          console.log(`   Capacity: ${table.capacity} people`);
          console.log(`   Started: ${new Date(session.started_at).toLocaleString()}`);
          console.log(`   Status: ${session.status || 'OPEN'}`);
          console.log(`   Orders placed: ${orderCount}`);
          console.log(`   Branch Match: ${isCorrectBranch ? '✅' : '❌'}`);
          console.log('');
        }
      }
      
      console.log('═══════════════════════════════════════════════════════');
      console.log('\n💡 BRANCH FILTERING:\n');
      console.log('✅ Captain only sees tables from their branch');
      console.log('✅ Prevents cross-branch order confusion');
      console.log('✅ JWT token identifies captain\'s branch\n');
      
      console.log('═══════════════════════════════════════════════════════');
      console.log('\n💡 USAGE FOR CAPTAIN APP:\n');
      console.log('1. Captain logs in → receives JWT token');
      console.log('2. App calls GET /staff/active-tables with token');
      console.log('3. Captain sees only their branch\'s active tables');
      console.log('4. Selects table to take order');
      console.log('5. Uses sessionId in place order request\n');
      
      if (activeTables.length > 0) {
        console.log('Example request with authentication:');
        console.log('─'.repeat(55));
        console.log('GET /staff/active-tables');
        console.log('Authorization: Bearer ' + token.substring(0, 30) + '...');
        console.log('');
        console.log('Then place order:');
        console.log('POST /public/order/place?sessionId=' + activeTables[0].id);
        console.log('Body:');
        console.log(JSON.stringify({
          items: [
            { menuItemId: "<menu-item-uuid>", qty: 2 }
          ]
        }, null, 2));
        console.log('─'.repeat(55));
      }
      
    } else {
      console.log('❌ Failed to get active tables');
      console.log('Response:', activeTables);
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error(error);
  } finally {
    await db.pool.end();
  }
}

testActiveTables();
