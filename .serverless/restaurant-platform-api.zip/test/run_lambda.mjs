import dotenv from 'dotenv';
dotenv.config();

// ensure a local fallback JWT secret for test runs
process.env.JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_for_tests';

const dbModule = (await import('../src/libs/db.js')).default;
const { handler: loginHandler } = await import('../src/staff/login.js');
const { handler: createRestaurant } = await import('../src/super-admin/createRestaurant.js');

async function run() {
  // 1) login as super admin (username: super1)
  const loginEvent = { body: JSON.stringify({ username: 'super1' }) };
  const loginRes = await loginHandler(loginEvent);
  const token = JSON.parse(loginRes.body).token || JSON.parse(loginRes.body).token || loginRes.body && JSON.parse(loginRes.body).token || (loginRes.token);

  // 2) create restaurant using super admin token
  const event = {
    body: JSON.stringify({
      name: 'Kiran Spice Test',
      logoUrl: 'spice_test.png',
      primaryColor: '#FF5722',
      secondaryColor: '#4CAF50'
    }),
    headers: { authorization: `Bearer ${token}` }
  };

  try {
    const res = await createRestaurant(event, {}, { db: dbModule });
    console.log('LAMBDA RESPONSE:', res);
  } catch (err) {
    console.error('LAMBDA ERROR:', err);
    process.exit(1);
  } finally {
    // close pool if available
    if (dbModule && dbModule.pool && dbModule.pool.end) await dbModule.pool.end();
  }
}

run();
