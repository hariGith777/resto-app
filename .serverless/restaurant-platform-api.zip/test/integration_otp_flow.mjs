import dotenv from 'dotenv';
dotenv.config();

import jwt from 'jsonwebtoken';
const dbModule = (await import('../src/libs/db.js')).default;
const { handler: startSession } = await import('../src/public/qr/startSession.js');
const { handler: initiateCustomer } = await import('../src/public/customer/initiate.js');
const { handler: generateOtp } = await import('../src/staff/otp/generate.js');
const { handler: verifyOtp } = await import('../src/public/customer/verifyOtp.js');

async function seed() {
  // create restaurant -> branch -> area -> table
  const r = await dbModule.query("INSERT INTO restaurants(name) VALUES($1) RETURNING id", ['Test R']);
  const restaurantId = r.rows[0].id;
  const b = await dbModule.query("INSERT INTO branches(restaurant_id, name) VALUES($1,$2) RETURNING id", [restaurantId, 'Main Branch']);
  const branchId = b.rows[0].id;
  const a = await dbModule.query("INSERT INTO areas(branch_id, name) VALUES($1,$2) RETURNING id", [branchId, 'Ground Floor']);
  const areaId = a.rows[0].id;
  const t = await dbModule.query("INSERT INTO tables(area_id, table_number, qr_code) VALUES($1,$2,$3) RETURNING id", [areaId, 'T1', 'qr://test']);
  const tableId = t.rows[0].id;

  // create a staff captain
  const s = await dbModule.query("INSERT INTO staff(branch_id, name, username, role, phone) VALUES($1,$2,$3,$4,$5) RETURNING id", [branchId, 'Captain Test', 'captain1', 'CAPTAIN', '9000000000']);
  const staffId = s.rows[0].id;
  return { restaurantId, branchId, areaId, tableId, staffId };
}

async function run() {
  try {
    console.log('Seeding data...');
    const ids = await seed();

    console.log('Starting session via handler');
    const startRes = await startSession({ body: JSON.stringify({ tableId: ids.tableId }) });
    console.log('startSession response', startRes);
    const sessionId = JSON.parse(startRes.body).sessionId;

    console.log('Initiating customer');
    const phone = '9876543210';
    const initRes = await initiateCustomer({ body: JSON.stringify({ sessionId, name: 'Rahul', phone }) });
    console.log('initiateCustomer response', initRes.body);

    // create staff JWT
    const staffPayload = { staffId: ids.staffId, role: 'CAPTAIN', branchId: ids.branchId };
    const staffToken = jwt.sign(staffPayload, process.env.JWT_SECRET || 'dev_secret_for_tests', { expiresIn: '1h' });

    console.log('Captain generating OTP');
    const genRes = await generateOtp({ body: JSON.stringify({ sessionId, customerPhone: phone }), headers: { authorization: `Bearer ${staffToken}` } });
    console.log('generateOtp response', genRes.body);
    const otp = JSON.parse(genRes.body).otp;

    console.log('Customer verifying OTP');
    const verifyRes = await verifyOtp({ body: JSON.stringify({ sessionId, phone, otp }) });
    console.log('verifyOtp response', verifyRes);
    const token = JSON.parse(verifyRes.body).token;

    console.log('Decoded token:', jwt.verify(token, process.env.JWT_SECRET || 'dev_secret_for_tests'));

    console.log('Integration OTP flow completed successfully');
  } catch (err) {
    console.error('Integration flow failed', err);
  } finally {
    await dbModule.pool.end?.();
  }
}

run();
