import { query, default as db } from './src/libs/db.js';
import { handler } from './src/public/order/placeOrder.js';

async function runTests() {
  try {
    console.log('🧪 TESTING PLACEORDER HANDLER - EDGE CASES\n');
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Get test data
    const sessionsRes = await query('SELECT id FROM table_sessions LIMIT 1');
    const sessionId = sessionsRes.rows[0]?.id;
    
    const menuItemsRes = await query('SELECT id FROM menu_items LIMIT 1');
    const menuItemId = menuItemsRes.rows[0]?.id;
    
    const portionsRes = await query('SELECT id FROM menu_portions LIMIT 1');
    const portionId = portionsRes.rows[0]?.id;
    
    // Test cases
    const tests = [
      {
        name: 'Test 1: Missing sessionId',
        input: {
          queryStringParameters: {},
          body: JSON.stringify({ items: [{ menuItemId, qty: 1 }] })
        },
        expectedStatus: 400,
        expectedError: 'sessionId required'
      },
      {
        name: 'Test 2: Missing items',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({})
        },
        expectedStatus: 400,
        expectedError: 'items array required'
      },
      {
        name: 'Test 3: Empty items array',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({ items: [] })
        },
        expectedStatus: 400,
        expectedError: 'items array required'
      },
      {
        name: 'Test 4: Invalid session ID',
        input: {
          queryStringParameters: { sessionId: '00000000-0000-0000-0000-000000000000' },
          body: JSON.stringify({ items: [{ menuItemId, qty: 1 }] })
        },
        expectedStatus: 404,
        expectedError: 'Session not found'
      },
      {
        name: 'Test 5: Invalid menu item ID',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({ items: [{ menuItemId: '00000000-0000-0000-0000-000000000000', qty: 1 }] })
        },
        expectedStatus: 404,
        expectedError: 'Menu item'
      },
      {
        name: 'Test 6: Invalid quantity (zero)',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({ items: [{ menuItemId, qty: 0 }] })
        },
        expectedStatus: 400,
        expectedError: 'Invalid item format'
      },
      {
        name: 'Test 7: Invalid quantity (negative)',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({ items: [{ menuItemId, qty: -1 }] })
        },
        expectedStatus: 400,
        expectedError: 'Invalid item format'
      },
      {
        name: 'Test 8: Valid order without portion',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({ items: [{ menuItemId, qty: 2 }] })
        },
        expectedStatus: 201,
        expectedError: null
      },
      {
        name: 'Test 9: Valid order with portion',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({ items: [{ menuItemId, portionId, qty: 1 }] })
        },
        expectedStatus: 201,
        expectedError: null
      },
      {
        name: 'Test 10: Multiple items order',
        input: {
          queryStringParameters: { sessionId },
          body: JSON.stringify({ 
            items: [
              { menuItemId, qty: 2 },
              { menuItemId, portionId, qty: 1 }
            ]
          })
        },
        expectedStatus: 201,
        expectedError: null
      }
    ];
    
    // Run tests
    let passed = 0;
    let failed = 0;
    
    for (const test of tests) {
      console.log(`\n${test.name}`);
      console.log('─'.repeat(55));
      
      try {
        const response = await handler(test.input);
        const body = JSON.parse(response.body);
        
        if (response.statusCode === test.expectedStatus) {
          if (test.expectedError) {
            if (body.error && body.error.includes(test.expectedError)) {
              console.log(`✅ PASS - Status: ${response.statusCode}, Error: "${body.error}"`);
              passed++;
            } else {
              console.log(`❌ FAIL - Expected error containing "${test.expectedError}", got: "${body.error}"`);
              failed++;
            }
          } else {
            console.log(`✅ PASS - Status: ${response.statusCode}, Order ID: ${body.orderId}`);
            passed++;
          }
        } else {
          console.log(`❌ FAIL - Expected status ${test.expectedStatus}, got ${response.statusCode}`);
          console.log(`   Response:`, body);
          failed++;
        }
      } catch (error) {
        console.log(`❌ FAIL - Exception: ${error.message}`);
        failed++;
      }
    }
    
    // Summary
    console.log('\n\n═══════════════════════════════════════════════════════');
    console.log('TEST SUMMARY');
    console.log('═══════════════════════════════════════════════════════');
    console.log(`Total Tests: ${tests.length}`);
    console.log(`✅ Passed: ${passed}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`Success Rate: ${((passed / tests.length) * 100).toFixed(1)}%`);
    console.log('═══════════════════════════════════════════════════════\n');
    
  } catch (error) {
    console.error('❌ Test suite failed:', error.message);
    console.error(error);
  } finally {
    await db.pool.end();
  }
}

runTests();
