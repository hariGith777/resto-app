import { query, default as db } from './src/libs/db.js';
import { handler } from './src/public/order/placeOrder.js';
import { handler as verifyOtpHandler } from './src/public/customer/verifyOtp.js';

async function testPlaceOrderWithCustomer() {
  try {
    console.log('🔍 TESTING PLACEORDER WITH CUSTOMER_ID\n');
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Get test data
    const sessionsRes = await query('SELECT id FROM table_sessions LIMIT 1');
    const sessionId = sessionsRes.rows[0]?.id;
    
    const menuItemsRes = await query('SELECT id, name, base_price FROM menu_items LIMIT 2');
    const menuItems = menuItemsRes.rows;
    
    // Get a verified customer
    const customerRes = await query(
      'SELECT id FROM customers WHERE verified = true LIMIT 1'
    );
    
    let customerToken = null;
    let customerId = null;
    
    if (customerRes.rowCount > 0) {
      customerId = customerRes.rows[0].id;
      console.log('✅ Found verified customer:', customerId);
      
      // Create a test token for the customer
      const jwt = await import('jsonwebtoken');
      customerToken = jwt.default.sign(
        { sessionId, customerId, scope: 'session' },
        process.env.JWT_SECRET
      );
      console.log('✅ Generated customer token\n');
    } else {
      console.log('⚠️  No verified customer found, will test without customer_id\n');
    }
    
    // Prepare test order
    const testOrderItems = menuItems.map(item => ({
      menuItemId: item.id,
      qty: 2
    }));
    
    console.log('═══════════════════════════════════════════════════════');
    console.log('TEST 1: Customer Self-Order (WITH TOKEN)\n');
    console.log('─'.repeat(55));
    
    if (customerToken) {
      const response1 = await handler({
        queryStringParameters: { sessionId },
        body: JSON.stringify({ items: testOrderItems }),
        headers: { authorization: `Bearer ${customerToken}` }
      });
      
      const result1 = JSON.parse(response1.body);
      console.log(`Status: ${response1.statusCode}`);
      console.log(`Order ID: ${result1.orderId}`);
      console.log(`Total: ₹${result1.totalAmount}\n`);
      
      if (response1.statusCode === 201) {
        // Verify customer_id was set
        const orderCheck = await query(
          'SELECT id, session_id, customer_id, status, total_amount FROM orders WHERE id = $1',
          [result1.orderId]
        );
        
        console.log('Order Details:');
        console.log(`  Order ID: ${orderCheck.rows[0].id}`);
        console.log(`  Session ID: ${orderCheck.rows[0].session_id}`);
        console.log(`  Customer ID: ${orderCheck.rows[0].customer_id || 'NULL'}`);
        console.log(`  Status: ${orderCheck.rows[0].status}`);
        console.log(`  Total: ₹${orderCheck.rows[0].total_amount}\n`);
        
        if (orderCheck.rows[0].customer_id === customerId) {
          console.log('✅ SUCCESS: customer_id correctly set!\n');
        } else {
          console.log('❌ FAILED: customer_id not set or incorrect\n');
        }
      }
    } else {
      console.log('⚠️  Skipped - no verified customer available\n');
    }
    
    console.log('═══════════════════════════════════════════════════════');
    console.log('TEST 2: Captain Order (WITHOUT TOKEN)\n');
    console.log('─'.repeat(55));
    
    const response2 = await handler({
      queryStringParameters: { sessionId },
      body: JSON.stringify({ items: testOrderItems }),
      headers: {} // No authorization header
    });
    
    const result2 = JSON.parse(response2.body);
    console.log(`Status: ${response2.statusCode}`);
    console.log(`Order ID: ${result2.orderId}`);
    console.log(`Total: ₹${result2.totalAmount}\n`);
    
    if (response2.statusCode === 201) {
      // Verify customer_id is NULL
      const orderCheck = await query(
        'SELECT id, session_id, customer_id, status, total_amount FROM orders WHERE id = $1',
        [result2.orderId]
      );
      
      console.log('Order Details:');
      console.log(`  Order ID: ${orderCheck.rows[0].id}`);
      console.log(`  Session ID: ${orderCheck.rows[0].session_id}`);
      console.log(`  Customer ID: ${orderCheck.rows[0].customer_id || 'NULL'}`);
      console.log(`  Status: ${orderCheck.rows[0].status}`);
      console.log(`  Total: ₹${orderCheck.rows[0].total_amount}\n`);
      
      if (orderCheck.rows[0].customer_id === null) {
        console.log('✅ SUCCESS: customer_id correctly NULL for captain order!\n');
      } else {
        console.log('❌ FAILED: customer_id should be NULL for captain orders\n');
      }
    }
    
    console.log('═══════════════════════════════════════════════════════');
    console.log('SUMMARY\n');
    console.log('✅ Customer orders have customer_id set');
    console.log('✅ Captain orders have customer_id NULL');
    console.log('✅ Both order types work correctly');
    console.log('═══════════════════════════════════════════════════════\n');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error(error);
  } finally {
    await db.pool.end();
  }
}

testPlaceOrderWithCustomer();
