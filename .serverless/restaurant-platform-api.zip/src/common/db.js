import libsDb from "../libs/db.js";

export const db = libsDb;

export default db;
