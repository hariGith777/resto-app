import { db } from "../../common/db.js";

export const handler = async ({ pathParameters, queryStringParameters }) => {
  try {
    const orderId = pathParameters?.orderId || queryStringParameters?.orderId;
    if (!orderId) {
      return { statusCode: 400, body: JSON.stringify({ error: "orderId required" }) };
    }

    // Fetch order with items
    const orderRes = await db.query(
      `SELECT o.id, o.session_id, o.customer_id, o.status, o.total_amount, o.created_at
       FROM orders o
       WHERE o.id = $1`,
      [orderId]
    );

    if (!orderRes.rowCount) {
      return { statusCode: 404, body: JSON.stringify({ error: "Order not found" }) };
    }

    const order = orderRes.rows[0];

    // Fetch order items
    const itemsRes = await db.query(
      `SELECT oi.id, oi.menu_item_id, oi.portion_id, oi.qty, oi.price,
              mi.name, mi.description
       FROM order_items oi
       JOIN menu_items mi ON mi.id = oi.menu_item_id
       WHERE oi.order_id = $1`,
      [orderId]
    );

    return {
      statusCode: 200,
      body: JSON.stringify({
        ...order,
        items: itemsRes.rows
      })
    };
  } catch (error) {
    console.error("Get order error:", error);
    return { statusCode: 500, body: JSON.stringify({ error: "Internal server error" }) };
  }
};
