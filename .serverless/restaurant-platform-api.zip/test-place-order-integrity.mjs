import { query, default as db } from './src/libs/db.js';
import { handler } from './src/public/order/placeOrder.js';

async function testDataIntegrity() {
  try {
    console.log('🧪 TESTING DATA INTEGRITY & TRANSACTION ROLLBACK\n');
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Get test data
    const sessionsRes = await query('SELECT id FROM table_sessions LIMIT 1');
    const sessionId = sessionsRes.rows[0]?.id;
    
    const menuItemsRes = await query('SELECT id, name, base_price FROM menu_items LIMIT 2');
    const items = menuItemsRes.rows;
    
    // TEST 1: Verify complete order creation
    console.log('Test 1: Verify complete order with multiple items\n');
    console.log('─'.repeat(55));
    
    const orderItems = items.map((item, i) => ({
      menuItemId: item.id,
      qty: i + 2
    }));
    
    const response = await handler({
      queryStringParameters: { sessionId },
      body: JSON.stringify({ items: orderItems })
    });
    
    const result = JSON.parse(response.body);
    console.log(`✅ Order created: ${result.orderId}\n`);
    
    // Verify order
    const orderCheck = await query('SELECT * FROM orders WHERE id = $1', [result.orderId]);
    console.log('Order Record:');
    console.log(`  ID: ${orderCheck.rows[0].id}`);
    console.log(`  Session ID: ${orderCheck.rows[0].session_id}`);
    console.log(`  Status: ${orderCheck.rows[0].status}`);
    console.log(`  Total Amount: ₹${orderCheck.rows[0].total_amount}`);
    console.log(`  Created: ${orderCheck.rows[0].created_at}\n`);
    
    // Verify order items
    const itemsCheck = await query(
      `SELECT oi.*, mi.name 
       FROM order_items oi 
       JOIN menu_items mi ON oi.menu_item_id = mi.id 
       WHERE oi.order_id = $1 
       ORDER BY oi.id`,
      [result.orderId]
    );
    
    console.log(`Order Items (${itemsCheck.rows.length} items):`);
    let calculatedTotal = 0;
    itemsCheck.rows.forEach((item, i) => {
      const lineTotal = parseFloat(item.price) * item.qty;
      calculatedTotal += lineTotal;
      console.log(`  ${i + 1}. ${item.name}`);
      console.log(`     Qty: ${item.qty}, Price: ₹${item.price}, Line Total: ₹${lineTotal}`);
    });
    console.log(`  Calculated Total: ₹${calculatedTotal}\n`);
    
    // Verify KOT
    const kotCheck = await query('SELECT * FROM kots WHERE order_id = $1', [result.orderId]);
    console.log('KOT Record:');
    console.log(`  ID: ${kotCheck.rows[0].id}`);
    console.log(`  Order ID: ${kotCheck.rows[0].order_id}`);
    console.log(`  Status: ${kotCheck.rows[0].status}`);
    console.log(`  Created: ${kotCheck.rows[0].created_at}\n`);
    
    // Verify total matches
    const totalMatches = parseFloat(orderCheck.rows[0].total_amount) === calculatedTotal;
    console.log(`Total Amount Verification: ${totalMatches ? '✅ PASS' : '❌ FAIL'}`);
    console.log(`  Expected: ₹${calculatedTotal}`);
    console.log(`  Actual: ₹${orderCheck.rows[0].total_amount}\n`);
    
    // TEST 2: Verify transaction rollback on invalid portion
    console.log('\n═══════════════════════════════════════════════════════\n');
    console.log('Test 2: Verify transaction rollback on error\n');
    console.log('─'.repeat(55));
    
    const beforeCount = await query('SELECT COUNT(*) FROM orders');
    const beforeOrderCount = parseInt(beforeCount.rows[0].count);
    console.log(`Orders before invalid request: ${beforeOrderCount}`);
    
    // Try to create order with invalid portion
    const invalidResponse = await handler({
      queryStringParameters: { sessionId },
      body: JSON.stringify({ 
        items: [
          { menuItemId: items[0].id, portionId: '00000000-0000-0000-0000-000000000000', qty: 1 }
        ]
      })
    });
    
    const afterCount = await query('SELECT COUNT(*) FROM orders');
    const afterOrderCount = parseInt(afterCount.rows[0].count);
    console.log(`Orders after invalid request: ${afterOrderCount}`);
    console.log(`Response status: ${invalidResponse.statusCode}`);
    console.log(`Response error: ${JSON.parse(invalidResponse.body).error}\n`);
    
    const noOrphanedRecords = beforeOrderCount === afterOrderCount;
    console.log(`Transaction Rollback Verification: ${noOrphanedRecords ? '✅ PASS' : '❌ FAIL'}`);
    console.log(`  No orphaned order records created\n`);
    
    // TEST 3: Verify price snapshot (important for historical accuracy)
    console.log('═══════════════════════════════════════════════════════\n');
    console.log('Test 3: Verify price snapshot mechanism\n');
    console.log('─'.repeat(55));
    
    const priceCheck = await query(
      `SELECT mi.base_price as current_price, oi.price as snapshot_price, oi.menu_item_id
       FROM order_items oi
       JOIN menu_items mi ON oi.menu_item_id = mi.id
       WHERE oi.order_id = $1`,
      [result.orderId]
    );
    
    console.log('Price Comparison:');
    let allMatch = true;
    priceCheck.rows.forEach((row, i) => {
      const matches = parseFloat(row.current_price) === parseFloat(row.snapshot_price);
      allMatch = allMatch && matches;
      console.log(`  Item ${i + 1}:`);
      console.log(`    Current Price: ₹${row.current_price}`);
      console.log(`    Snapshot Price: ₹${row.snapshot_price}`);
      console.log(`    Match: ${matches ? '✅' : '❌'}`);
    });
    
    console.log(`\nPrice Snapshot Verification: ${allMatch ? '✅ PASS' : '❌ FAIL'}`);
    console.log(`  All prices correctly snapshotted at order time\n`);
    
    // Final Summary
    console.log('═══════════════════════════════════════════════════════');
    console.log('DATA INTEGRITY TEST SUMMARY');
    console.log('═══════════════════════════════════════════════════════');
    console.log(`${totalMatches ? '✅' : '❌'} Order total calculation`);
    console.log(`${itemsCheck.rows.length === orderItems.length ? '✅' : '❌'} All order items saved`);
    console.log(`${kotCheck.rows.length === 1 ? '✅' : '❌'} KOT created`);
    console.log(`${noOrphanedRecords ? '✅' : '❌'} Transaction rollback working`);
    console.log(`${allMatch ? '✅' : '❌'} Price snapshot mechanism`);
    console.log('═══════════════════════════════════════════════════════\n');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error(error);
  } finally {
    await db.pool.end();
  }
}

testDataIntegrity();
