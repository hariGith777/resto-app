import { handler as loginHandler } from './src/staff/login.js';
import { handler as activeTablesHandler } from './src/staff/activeTables.js';
import { default as db } from './src/libs/db.js';

async function testBranchIsolation() {
  try {
    console.log('🔍 TESTING BRANCH ISOLATION\n');
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Test with captain_raj (Branch 1)
    console.log('Test 1: Captain Raj');
    console.log('─'.repeat(55));
    const raj = await loginHandler({ body: JSON.stringify({ username: 'captain_raj' }) });
    const rajData = JSON.parse(raj.body);
    const rajTables = await activeTablesHandler({ headers: { authorization: 'Bearer ' + rajData.token } });
    const rajSessions = JSON.parse(rajTables.body);
    const rajCount = rajSessions.length;
    console.log(`Branch ID: ${rajData.branchId}`);
    console.log(`Active Sessions: ${rajCount}\n`);
    
    // Test with captain_arjun (Branch 2)
    console.log('Test 2: Captain Arjun');
    console.log('─'.repeat(55));
    const arjun = await loginHandler({ body: JSON.stringify({ username: 'captain_arjun' }) });
    const arjunData = JSON.parse(arjun.body);
    const arjunTables = await activeTablesHandler({ headers: { authorization: 'Bearer ' + arjunData.token } });
    const arjunSessions = JSON.parse(arjunTables.body);
    const arjunCount = arjunSessions.length;
    console.log(`Branch ID: ${arjunData.branchId}`);
    console.log(`Active Sessions: ${arjunCount}\n`);
    
    console.log('═══════════════════════════════════════════════════════');
    console.log('VERIFICATION:\n');
    
    const differentBranches = rajData.branchId !== arjunData.branchId;
    console.log(`${differentBranches ? '✅' : '❌'} Captains from different branches`);
    console.log(`   Captain Raj Branch: ${rajData.branchId}`);
    console.log(`   Captain Arjun Branch: ${arjunData.branchId}\n`);
    
    console.log(`${rajCount > 0 ? '✅' : '⚠️'} Captain Raj sees ${rajCount} active session(s)`);
    console.log(`${arjunCount >= 0 ? '✅' : '⚠️'} Captain Arjun sees ${arjunCount} active session(s)\n`);
    
    // Verify no session overlap
    const rajIds = new Set(rajSessions.map(s => s.id));
    const arjunIds = new Set(arjunSessions.map(s => s.id));
    const overlap = [...rajIds].filter(id => arjunIds.has(id));
    
    console.log(`${overlap.length === 0 ? '✅' : '❌'} No session overlap between branches`);
    console.log(`   Overlapping sessions: ${overlap.length}\n`);
    
    console.log('═══════════════════════════════════════════════════════');
    console.log('RESULT:\n');
    
    if (differentBranches && overlap.length === 0) {
      console.log('✅ BRANCH ISOLATION WORKING CORRECTLY\n');
      console.log('Each captain only sees tables from their own branch.');
      console.log('This prevents cross-branch order confusion.\n');
    } else {
      console.log('⚠️ POTENTIAL ISSUE DETECTED\n');
    }
    
    console.log('═══════════════════════════════════════════════════════\n');
    
    await db.pool.end();
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

testBranchIsolation();
